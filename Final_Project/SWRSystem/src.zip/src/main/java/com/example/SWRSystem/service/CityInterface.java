package com.example.SWRSystem.service;

import java.util.List;

import com.example.SWRSystem.dao.City;

public interface CityInterface {
	
	public List<City> getCity();
}
