package com.example.SWRSystem.service;

import java.util.List;

import com.example.SWRSystem.dao.Skill;

public interface SkillsInterface {

	public List<Skill> getSkill();
	
}
