package com.example.SWRSystem.service;

public interface SkillsInterface {

	
}
