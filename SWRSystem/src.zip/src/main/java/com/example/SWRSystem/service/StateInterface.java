package com.example.SWRSystem.service;

import java.util.List;

import com.example.SWRSystem.dao.State;

public interface StateInterface {
	
	public List<State> getState();
}
