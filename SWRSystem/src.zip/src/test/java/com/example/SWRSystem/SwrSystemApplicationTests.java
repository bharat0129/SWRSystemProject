package com.example.SWRSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwrSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
